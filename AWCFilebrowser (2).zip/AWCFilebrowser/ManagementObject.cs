﻿namespace file_tree_clock_web1
{
	internal class ManagementObject
	{
	}
}
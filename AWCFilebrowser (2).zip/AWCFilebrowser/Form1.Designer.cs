﻿namespace file_tree_clock_web1
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && ( components != null )) {
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.fileTree = new System.Windows.Forms.TreeView();
			this.fileTreeContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.フォルダ作成ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.名称変更ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.カットToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.コピーToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ペーストToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.削除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.元に戻す = new System.Windows.Forms.ToolStripMenuItem();
			this.他のアプリケーションで開くToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.再生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.label2 = new System.Windows.Forms.Label();
			this.lastWriteTime = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.fileLength = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.creationTime = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.lastAccessTime = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.rExtension = new System.Windows.Forms.Label();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.passNameLabel = new System.Windows.Forms.Label();
			this.fileNameLabel = new System.Windows.Forms.Label();
			this.playerWebBrowser = new System.Windows.Forms.WebBrowser();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.splitContainerLeftTop = new System.Windows.Forms.SplitContainer();
			this.playListRedoroe = new System.Windows.Forms.Button();
			this.splitContainerCenter = new System.Windows.Forms.SplitContainer();
			this.continuousPlayCheckBox = new System.Windows.Forms.CheckBox();
			this.mineType = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.typeName = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.splitContainer2 = new System.Windows.Forms.SplitContainer();
			this.splitContainer3 = new System.Windows.Forms.SplitContainer();
			this.progresPanel = new System.Windows.Forms.Panel();
			this.prgMessageLabel = new System.Windows.Forms.Label();
			this.ProgressMaxLabel = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.targetCountLabel = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.progCountLabel = new System.Windows.Forms.Label();
			this.ProgressTitolLabel = new System.Windows.Forms.Label();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			this.playListBox = new System.Windows.Forms.ListBox();
			this.PlayListContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ファイルブラウザで選択 = new System.Windows.Forms.ToolStripMenuItem();
			this.parentPathLabel = new System.Windows.Forms.Label();
			this.grarnPathLabel = new System.Windows.Forms.Label();
			this.plRewButton = new System.Windows.Forms.Button();
			this.plNextBbutton = new System.Windows.Forms.Button();
			this.plTotalLabel = new System.Windows.Forms.Label();
			this.plPosisionLabel = new System.Windows.Forms.Label();
			this.upDirButton = new System.Windows.Forms.Button();
			this.fileTreeContextMenuStrip.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainerLeftTop)).BeginInit();
			this.splitContainerLeftTop.Panel1.SuspendLayout();
			this.splitContainerLeftTop.Panel2.SuspendLayout();
			this.splitContainerLeftTop.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainerCenter)).BeginInit();
			this.splitContainerCenter.Panel1.SuspendLayout();
			this.splitContainerCenter.Panel2.SuspendLayout();
			this.splitContainerCenter.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
			this.splitContainer2.Panel1.SuspendLayout();
			this.splitContainer2.Panel2.SuspendLayout();
			this.splitContainer2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
			this.splitContainer3.Panel1.SuspendLayout();
			this.splitContainer3.Panel2.SuspendLayout();
			this.splitContainer3.SuspendLayout();
			this.progresPanel.SuspendLayout();
			this.PlayListContextMenuStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// fileTree
			// 
			this.fileTree.AllowDrop = true;
			this.fileTree.Dock = System.Windows.Forms.DockStyle.Fill;
			this.fileTree.Location = new System.Drawing.Point(0, 0);
			this.fileTree.Name = "fileTree";
			this.fileTree.Size = new System.Drawing.Size(353, 320);
			this.fileTree.TabIndex = 7;
			this.fileTree.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.TreeView1_BeforeExpand);
			this.fileTree.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.TreeView1_ItemDrag);
			this.fileTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TreeView1_AfterSelect);
			this.fileTree.DragDrop += new System.Windows.Forms.DragEventHandler(this.TreeView1_DragDrop);
			this.fileTree.DragOver += new System.Windows.Forms.DragEventHandler(this.TreeView1_DragOver);
			this.fileTree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FileTree_KeyUp);
			this.fileTree.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FilelistBoxMouseUp);
			// 
			// fileTreeContextMenuStrip
			// 
			this.fileTreeContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.フォルダ作成ToolStripMenuItem,
            this.名称変更ToolStripMenuItem,
            this.カットToolStripMenuItem,
            this.コピーToolStripMenuItem,
            this.ペーストToolStripMenuItem,
            this.削除ToolStripMenuItem,
            this.元に戻す,
            this.他のアプリケーションで開くToolStripMenuItem,
            this.再生ToolStripMenuItem});
			this.fileTreeContextMenuStrip.Name = "contextMenuStrip1";
			this.fileTreeContextMenuStrip.Size = new System.Drawing.Size(195, 202);
			this.fileTreeContextMenuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ContextMenuStrip1_ItemClicked);
			// 
			// フォルダ作成ToolStripMenuItem
			// 
			this.フォルダ作成ToolStripMenuItem.Name = "フォルダ作成ToolStripMenuItem";
			this.フォルダ作成ToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.フォルダ作成ToolStripMenuItem.Text = "フォルダ作成";
			// 
			// 名称変更ToolStripMenuItem
			// 
			this.名称変更ToolStripMenuItem.Name = "名称変更ToolStripMenuItem";
			this.名称変更ToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.名称変更ToolStripMenuItem.Text = "名称変更";
			// 
			// カットToolStripMenuItem
			// 
			this.カットToolStripMenuItem.Name = "カットToolStripMenuItem";
			this.カットToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.カットToolStripMenuItem.Text = "カット";
			// 
			// コピーToolStripMenuItem
			// 
			this.コピーToolStripMenuItem.Name = "コピーToolStripMenuItem";
			this.コピーToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.コピーToolStripMenuItem.Text = "コピー";
			// 
			// ペーストToolStripMenuItem
			// 
			this.ペーストToolStripMenuItem.Name = "ペーストToolStripMenuItem";
			this.ペーストToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.ペーストToolStripMenuItem.Text = "ペースト";
			// 
			// 削除ToolStripMenuItem
			// 
			this.削除ToolStripMenuItem.Name = "削除ToolStripMenuItem";
			this.削除ToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.削除ToolStripMenuItem.Text = "削除";
			// 
			// 元に戻す
			// 
			this.元に戻す.Name = "元に戻す";
			this.元に戻す.Size = new System.Drawing.Size(194, 22);
			this.元に戻す.Text = "元に戻す";
			this.元に戻す.Visible = false;
			// 
			// 他のアプリケーションで開くToolStripMenuItem
			// 
			this.他のアプリケーションで開くToolStripMenuItem.Name = "他のアプリケーションで開くToolStripMenuItem";
			this.他のアプリケーションで開くToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.他のアプリケーションで開くToolStripMenuItem.Text = "他のアプリケーションで開く";
			// 
			// 再生ToolStripMenuItem
			// 
			this.再生ToolStripMenuItem.Name = "再生ToolStripMenuItem";
			this.再生ToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
			this.再生ToolStripMenuItem.Text = "再生";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(5, 11);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(41, 12);
			this.label2.TabIndex = 11;
			this.label2.Text = "更新日";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lastWriteTime
			// 
			this.lastWriteTime.AutoSize = true;
			this.lastWriteTime.Location = new System.Drawing.Point(50, 11);
			this.lastWriteTime.Name = "lastWriteTime";
			this.lastWriteTime.Size = new System.Drawing.Size(119, 12);
			this.lastWriteTime.TabIndex = 12;
			this.lastWriteTime.Text = "2999年12月31日 23:59";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(3, 63);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(68, 12);
			this.label3.TabIndex = 13;
			this.label3.Text = "ファイルサイズ";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// fileLength
			// 
			this.fileLength.AutoSize = true;
			this.fileLength.Location = new System.Drawing.Point(74, 63);
			this.fileLength.Name = "fileLength";
			this.fileLength.Size = new System.Drawing.Size(95, 12);
			this.fileLength.TabIndex = 14;
			this.fileLength.Text = "999999999999999";
			this.fileLength.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(3, 46);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(41, 12);
			this.label4.TabIndex = 15;
			this.label4.Text = "作成日";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// creationTime
			// 
			this.creationTime.AutoSize = true;
			this.creationTime.Location = new System.Drawing.Point(50, 47);
			this.creationTime.Name = "creationTime";
			this.creationTime.Size = new System.Drawing.Size(119, 12);
			this.creationTime.TabIndex = 16;
			this.creationTime.Text = "2999年12月31日 23:59";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(3, 29);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(41, 12);
			this.label5.TabIndex = 17;
			this.label5.Text = "アクセス";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lastAccessTime
			// 
			this.lastAccessTime.AutoSize = true;
			this.lastAccessTime.Location = new System.Drawing.Point(50, 29);
			this.lastAccessTime.Name = "lastAccessTime";
			this.lastAccessTime.Size = new System.Drawing.Size(119, 12);
			this.lastAccessTime.TabIndex = 18;
			this.lastAccessTime.Text = "2999年12月31日 23:59";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(175, 29);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(41, 12);
			this.label6.TabIndex = 19;
			this.label6.Text = "拡張子";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// rExtension
			// 
			this.rExtension.AutoSize = true;
			this.rExtension.Location = new System.Drawing.Point(222, 29);
			this.rExtension.Name = "rExtension";
			this.rExtension.Size = new System.Drawing.Size(0, 12);
			this.rExtension.TabIndex = 20;
			// 
			// imageList1
			// 
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			this.imageList1.Images.SetKeyName(0, "hd_icon.png");
			this.imageList1.Images.SetKeyName(1, "folder_close_icon.png");
			this.imageList1.Images.SetKeyName(2, "docment_icon.png");
			this.imageList1.Images.SetKeyName(3, "move_icon.png");
			this.imageList1.Images.SetKeyName(4, "pict_icon.png");
			this.imageList1.Images.SetKeyName(5, "music_icon.png");
			this.imageList1.Images.SetKeyName(6, "desktop_icon.png");
			this.imageList1.Images.SetKeyName(7, "pc_icon.png");
			this.imageList1.Images.SetKeyName(8, "folder_close_icon.png");
			this.imageList1.Images.SetKeyName(9, "phone_icon.png");
			this.imageList1.Images.SetKeyName(10, "hd_sys_icon.png");
			// 
			// passNameLabel
			// 
			this.passNameLabel.AutoSize = true;
			this.passNameLabel.Location = new System.Drawing.Point(5, 5);
			this.passNameLabel.Name = "passNameLabel";
			this.passNameLabel.Size = new System.Drawing.Size(0, 12);
			this.passNameLabel.TabIndex = 21;
			// 
			// fileNameLabel
			// 
			this.fileNameLabel.AutoSize = true;
			this.fileNameLabel.Location = new System.Drawing.Point(5, 25);
			this.fileNameLabel.Name = "fileNameLabel";
			this.fileNameLabel.Size = new System.Drawing.Size(41, 12);
			this.fileNameLabel.TabIndex = 22;
			this.fileNameLabel.Text = "未選択";
			// 
			// playerWebBrowser
			// 
			this.playerWebBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
			this.playerWebBrowser.Location = new System.Drawing.Point(0, 0);
			this.playerWebBrowser.Margin = new System.Windows.Forms.Padding(0);
			this.playerWebBrowser.MinimumSize = new System.Drawing.Size(20, 20);
			this.playerWebBrowser.Name = "playerWebBrowser";
			this.playerWebBrowser.ScrollBarsEnabled = false;
			this.playerWebBrowser.Size = new System.Drawing.Size(648, 452);
			this.playerWebBrowser.TabIndex = 25;
			this.playerWebBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.WebBrowser1_DocumentCompleted);
			this.playerWebBrowser.Resize += new System.EventHandler(this.ReSizeViews);
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.splitContainerLeftTop);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.AutoScroll = true;
			this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
			this.splitContainer1.Size = new System.Drawing.Size(1243, 452);
			this.splitContainer1.SplitterDistance = 353;
			this.splitContainer1.TabIndex = 27;
			// 
			// splitContainerLeftTop
			// 
			this.splitContainerLeftTop.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainerLeftTop.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainerLeftTop.Location = new System.Drawing.Point(0, 0);
			this.splitContainerLeftTop.Name = "splitContainerLeftTop";
			this.splitContainerLeftTop.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainerLeftTop.Panel1
			// 
			this.splitContainerLeftTop.Panel1.Controls.Add(this.playListRedoroe);
			this.splitContainerLeftTop.Panel1.Controls.Add(this.fileNameLabel);
			this.splitContainerLeftTop.Panel1.Controls.Add(this.passNameLabel);
			// 
			// splitContainerLeftTop.Panel2
			// 
			this.splitContainerLeftTop.Panel2.Controls.Add(this.splitContainerCenter);
			this.splitContainerLeftTop.Size = new System.Drawing.Size(353, 452);
			this.splitContainerLeftTop.SplitterDistance = 42;
			this.splitContainerLeftTop.TabIndex = 0;
			// 
			// playListRedoroe
			// 
			this.playListRedoroe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.playListRedoroe.Location = new System.Drawing.Point(278, 20);
			this.playListRedoroe.Name = "playListRedoroe";
			this.playListRedoroe.Size = new System.Drawing.Size(75, 23);
			this.playListRedoroe.TabIndex = 27;
			this.playListRedoroe.Text = "プレイリストへ";
			this.playListRedoroe.UseVisualStyleBackColor = true;
			this.playListRedoroe.Click += new System.EventHandler(this.PlayListRedoroe_Click);
			// 
			// splitContainerCenter
			// 
			this.splitContainerCenter.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainerCenter.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
			this.splitContainerCenter.IsSplitterFixed = true;
			this.splitContainerCenter.Location = new System.Drawing.Point(0, 0);
			this.splitContainerCenter.Name = "splitContainerCenter";
			this.splitContainerCenter.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainerCenter.Panel1
			// 
			this.splitContainerCenter.Panel1.AutoScroll = true;
			this.splitContainerCenter.Panel1.Controls.Add(this.fileTree);
			// 
			// splitContainerCenter.Panel2
			// 
			this.splitContainerCenter.Panel2.Controls.Add(this.continuousPlayCheckBox);
			this.splitContainerCenter.Panel2.Controls.Add(this.mineType);
			this.splitContainerCenter.Panel2.Controls.Add(this.label8);
			this.splitContainerCenter.Panel2.Controls.Add(this.typeName);
			this.splitContainerCenter.Panel2.Controls.Add(this.label7);
			this.splitContainerCenter.Panel2.Controls.Add(this.lastAccessTime);
			this.splitContainerCenter.Panel2.Controls.Add(this.rExtension);
			this.splitContainerCenter.Panel2.Controls.Add(this.label5);
			this.splitContainerCenter.Panel2.Controls.Add(this.fileLength);
			this.splitContainerCenter.Panel2.Controls.Add(this.creationTime);
			this.splitContainerCenter.Panel2.Controls.Add(this.label3);
			this.splitContainerCenter.Panel2.Controls.Add(this.label6);
			this.splitContainerCenter.Panel2.Controls.Add(this.lastWriteTime);
			this.splitContainerCenter.Panel2.Controls.Add(this.label4);
			this.splitContainerCenter.Panel2.Controls.Add(this.label2);
			this.splitContainerCenter.Panel2.Cursor = System.Windows.Forms.Cursors.Default;
			this.splitContainerCenter.Size = new System.Drawing.Size(353, 406);
			this.splitContainerCenter.SplitterDistance = 320;
			this.splitContainerCenter.TabIndex = 0;
			// 
			// continuousPlayCheckBox
			// 
			this.continuousPlayCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.continuousPlayCheckBox.AutoSize = true;
			this.continuousPlayCheckBox.Location = new System.Drawing.Point(276, 6);
			this.continuousPlayCheckBox.Name = "continuousPlayCheckBox";
			this.continuousPlayCheckBox.Size = new System.Drawing.Size(72, 16);
			this.continuousPlayCheckBox.TabIndex = 26;
			this.continuousPlayCheckBox.Text = "連続再生";
			this.continuousPlayCheckBox.UseVisualStyleBackColor = true;
			this.continuousPlayCheckBox.Click += new System.EventHandler(this.ContinuousPlayCheckBox_CheckedChanged);
			// 
			// mineType
			// 
			this.mineType.AutoSize = true;
			this.mineType.Location = new System.Drawing.Point(217, 63);
			this.mineType.Name = "mineType";
			this.mineType.Size = new System.Drawing.Size(62, 12);
			this.mineType.TabIndex = 24;
			this.mineType.Text = "MIME Type";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(178, 63);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(33, 12);
			this.label8.TabIndex = 23;
			this.label8.Text = "MIME";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// typeName
			// 
			this.typeName.AutoSize = true;
			this.typeName.Location = new System.Drawing.Point(217, 46);
			this.typeName.Name = "typeName";
			this.typeName.Size = new System.Drawing.Size(60, 12);
			this.typeName.TabIndex = 22;
			this.typeName.Text = "application";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(184, 46);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(29, 12);
			this.label7.TabIndex = 21;
			this.label7.Text = "分類";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// splitContainer2
			// 
			this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer2.Location = new System.Drawing.Point(0, 0);
			this.splitContainer2.Name = "splitContainer2";
			// 
			// splitContainer2.Panel1
			// 
			this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
			// 
			// splitContainer2.Panel2
			// 
			this.splitContainer2.Panel2.AllowDrop = true;
			this.splitContainer2.Panel2.AutoScroll = true;
			this.splitContainer2.Panel2.Controls.Add(this.playerWebBrowser);
			this.splitContainer2.Size = new System.Drawing.Size(886, 452);
			this.splitContainer2.SplitterDistance = 234;
			this.splitContainer2.TabIndex = 26;
			// 
			// splitContainer3
			// 
			this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer3.Location = new System.Drawing.Point(0, 0);
			this.splitContainer3.Name = "splitContainer3";
			this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer3.Panel1
			// 
			this.splitContainer3.Panel1.Controls.Add(this.progresPanel);
			this.splitContainer3.Panel1.Controls.Add(this.playListBox);
			// 
			// splitContainer3.Panel2
			// 
			this.splitContainer3.Panel2.Controls.Add(this.parentPathLabel);
			this.splitContainer3.Panel2.Controls.Add(this.grarnPathLabel);
			this.splitContainer3.Panel2.Controls.Add(this.plRewButton);
			this.splitContainer3.Panel2.Controls.Add(this.plNextBbutton);
			this.splitContainer3.Panel2.Controls.Add(this.plTotalLabel);
			this.splitContainer3.Panel2.Controls.Add(this.plPosisionLabel);
			this.splitContainer3.Panel2.Controls.Add(this.upDirButton);
			this.splitContainer3.Size = new System.Drawing.Size(234, 452);
			this.splitContainer3.SplitterDistance = 366;
			this.splitContainer3.TabIndex = 2;
			// 
			// progresPanel
			// 
			this.progresPanel.BackColor = System.Drawing.SystemColors.Window;
			this.progresPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.progresPanel.Controls.Add(this.prgMessageLabel);
			this.progresPanel.Controls.Add(this.ProgressMaxLabel);
			this.progresPanel.Controls.Add(this.label1);
			this.progresPanel.Controls.Add(this.targetCountLabel);
			this.progresPanel.Controls.Add(this.label9);
			this.progresPanel.Controls.Add(this.progCountLabel);
			this.progresPanel.Controls.Add(this.ProgressTitolLabel);
			this.progresPanel.Controls.Add(this.progressBar1);
			this.progresPanel.Location = new System.Drawing.Point(3, 100);
			this.progresPanel.Name = "progresPanel";
			this.progresPanel.Size = new System.Drawing.Size(228, 79);
			this.progresPanel.TabIndex = 4;
			this.progresPanel.Visible = false;
			// 
			// prgMessageLabel
			// 
			this.prgMessageLabel.AutoSize = true;
			this.prgMessageLabel.Location = new System.Drawing.Point(4, 61);
			this.prgMessageLabel.Name = "prgMessageLabel";
			this.prgMessageLabel.Size = new System.Drawing.Size(66, 12);
			this.prgMessageLabel.TabIndex = 18;
			this.prgMessageLabel.Text = "リストアップ中";
			// 
			// ProgressMaxLabel
			// 
			this.ProgressMaxLabel.AutoSize = true;
			this.ProgressMaxLabel.Location = new System.Drawing.Point(181, 38);
			this.ProgressMaxLabel.Name = "ProgressMaxLabel";
			this.ProgressMaxLabel.Size = new System.Drawing.Size(41, 12);
			this.ProgressMaxLabel.TabIndex = 17;
			this.ProgressMaxLabel.Text = "000000";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(164, 38);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(11, 12);
			this.label1.TabIndex = 16;
			this.label1.Text = "/";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// targetCountLabel
			// 
			this.targetCountLabel.AutoSize = true;
			this.targetCountLabel.Location = new System.Drawing.Point(98, 39);
			this.targetCountLabel.Name = "targetCountLabel";
			this.targetCountLabel.Size = new System.Drawing.Size(41, 12);
			this.targetCountLabel.TabIndex = 15;
			this.targetCountLabel.Text = "000000";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(51, 39);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(41, 12);
			this.label9.TabIndex = 14;
			this.label9.Text = ">対象>";
			this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// progCountLabel
			// 
			this.progCountLabel.Location = new System.Drawing.Point(4, 39);
			this.progCountLabel.Name = "progCountLabel";
			this.progCountLabel.Size = new System.Drawing.Size(41, 12);
			this.progCountLabel.TabIndex = 13;
			this.progCountLabel.Text = "000000";
			this.progCountLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// ProgressTitolLabel
			// 
			this.ProgressTitolLabel.AutoSize = true;
			this.ProgressTitolLabel.Location = new System.Drawing.Point(5, 4);
			this.ProgressTitolLabel.Name = "ProgressTitolLabel";
			this.ProgressTitolLabel.Size = new System.Drawing.Size(73, 12);
			this.ProgressTitolLabel.TabIndex = 4;
			this.ProgressTitolLabel.Text = "ProgressTitol";
			// 
			// progressBar1
			// 
			this.progressBar1.Location = new System.Drawing.Point(3, 22);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(222, 12);
			this.progressBar1.TabIndex = 3;
			// 
			// playListBox
			// 
			this.playListBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.playListBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.playListBox.FormattingEnabled = true;
			this.playListBox.ItemHeight = 12;
			this.playListBox.Location = new System.Drawing.Point(0, 0);
			this.playListBox.Name = "playListBox";
			this.playListBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.playListBox.Size = new System.Drawing.Size(234, 366);
			this.playListBox.TabIndex = 0;
			this.playListBox.Click += new System.EventHandler(this.PlayListBox_Select);
			this.playListBox.DoubleClick += new System.EventHandler(this.PlayListBox_Select);
			this.playListBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PlaylistBoxMouseUp);
			// 
			// PlayListContextMenuStrip
			// 
			this.PlayListContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルブラウザで選択});
			this.PlayListContextMenuStrip.Name = "PlayListContextMenuStrip";
			this.PlayListContextMenuStrip.Size = new System.Drawing.Size(179, 26);
			this.PlayListContextMenuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.PlayListContextMenuStrip_ItemClicked);
			// 
			// ファイルブラウザで選択
			// 
			this.ファイルブラウザで選択.Name = "ファイルブラウザで選択";
			this.ファイルブラウザで選択.Size = new System.Drawing.Size(178, 22);
			this.ファイルブラウザで選択.Text = "ファイルブラウザで選択";
			// 
			// parentPathLabel
			// 
			this.parentPathLabel.AutoSize = true;
			this.parentPathLabel.Location = new System.Drawing.Point(5, 39);
			this.parentPathLabel.Name = "parentPathLabel";
			this.parentPathLabel.Size = new System.Drawing.Size(87, 12);
			this.parentPathLabel.TabIndex = 34;
			this.parentPathLabel.Text = "parentPathLabel";
			// 
			// grarnPathLabel
			// 
			this.grarnPathLabel.AutoSize = true;
			this.grarnPathLabel.Location = new System.Drawing.Point(6, 22);
			this.grarnPathLabel.Name = "grarnPathLabel";
			this.grarnPathLabel.Size = new System.Drawing.Size(81, 12);
			this.grarnPathLabel.TabIndex = 33;
			this.grarnPathLabel.Text = "grarnPathLabel";
			// 
			// plRewButton
			// 
			this.plRewButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.plRewButton.BackColor = System.Drawing.Color.Transparent;
			this.plRewButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("plRewButton.BackgroundImage")));
			this.plRewButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.plRewButton.Location = new System.Drawing.Point(153, 3);
			this.plRewButton.Name = "plRewButton";
			this.plRewButton.Size = new System.Drawing.Size(30, 31);
			this.plRewButton.TabIndex = 32;
			this.plRewButton.UseVisualStyleBackColor = false;
			this.plRewButton.Click += new System.EventHandler(this.PlRewButton_Click);
			// 
			// plNextBbutton
			// 
			this.plNextBbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.plNextBbutton.AutoSize = true;
			this.plNextBbutton.BackColor = System.Drawing.Color.Transparent;
			this.plNextBbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.plNextBbutton.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
			this.plNextBbutton.Image = ((System.Drawing.Image)(resources.GetObject("plNextBbutton.Image")));
			this.plNextBbutton.Location = new System.Drawing.Point(185, 2);
			this.plNextBbutton.Name = "plNextBbutton";
			this.plNextBbutton.Size = new System.Drawing.Size(46, 46);
			this.plNextBbutton.TabIndex = 31;
			this.plNextBbutton.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.plNextBbutton.UseVisualStyleBackColor = false;
			this.plNextBbutton.Click += new System.EventHandler(this.PlNextBbutton_Click);
			// 
			// plTotalLabel
			// 
			this.plTotalLabel.AutoSize = true;
			this.plTotalLabel.Location = new System.Drawing.Point(190, 61);
			this.plTotalLabel.Name = "plTotalLabel";
			this.plTotalLabel.Size = new System.Drawing.Size(0, 12);
			this.plTotalLabel.TabIndex = 30;
			// 
			// plPosisionLabel
			// 
			this.plPosisionLabel.AutoSize = true;
			this.plPosisionLabel.Location = new System.Drawing.Point(6, 6);
			this.plPosisionLabel.Name = "plPosisionLabel";
			this.plPosisionLabel.Size = new System.Drawing.Size(76, 12);
			this.plPosisionLabel.TabIndex = 28;
			this.plPosisionLabel.Text = "posision/total";
			// 
			// upDirButton
			// 
			this.upDirButton.Location = new System.Drawing.Point(4, 56);
			this.upDirButton.Name = "upDirButton";
			this.upDirButton.Size = new System.Drawing.Size(121, 23);
			this.upDirButton.TabIndex = 27;
			this.upDirButton.Text = "上の階層をリストアップ";
			this.upDirButton.UseVisualStyleBackColor = true;
			this.upDirButton.Click += new System.EventHandler(this.UpDirButton_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.ClientSize = new System.Drawing.Size(1243, 452);
			this.Controls.Add(this.splitContainer1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(1055, 39);
			this.Name = "Form1";
			this.Text = "After watching the contents(中身を見てから)";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.fileTreeContextMenuStrip.ResumeLayout(false);
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.splitContainerLeftTop.Panel1.ResumeLayout(false);
			this.splitContainerLeftTop.Panel1.PerformLayout();
			this.splitContainerLeftTop.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainerLeftTop)).EndInit();
			this.splitContainerLeftTop.ResumeLayout(false);
			this.splitContainerCenter.Panel1.ResumeLayout(false);
			this.splitContainerCenter.Panel2.ResumeLayout(false);
			this.splitContainerCenter.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainerCenter)).EndInit();
			this.splitContainerCenter.ResumeLayout(false);
			this.splitContainer2.Panel1.ResumeLayout(false);
			this.splitContainer2.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
			this.splitContainer2.ResumeLayout(false);
			this.splitContainer3.Panel1.ResumeLayout(false);
			this.splitContainer3.Panel2.ResumeLayout(false);
			this.splitContainer3.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
			this.splitContainer3.ResumeLayout(false);
			this.progresPanel.ResumeLayout(false);
			this.progresPanel.PerformLayout();
			this.PlayListContextMenuStrip.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.TreeView fileTree;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lastWriteTime;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label fileLength;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label creationTime;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lastAccessTime;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label rExtension;
		private System.Windows.Forms.ImageList imageList1;
		private System.Windows.Forms.Label passNameLabel;
		private System.Windows.Forms.Label fileNameLabel;
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.SplitContainer splitContainerLeftTop;
		private System.Windows.Forms.SplitContainer splitContainerCenter;
		private System.Windows.Forms.Label mineType;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label typeName;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ContextMenuStrip fileTreeContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem 削除ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem フォルダ作成ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 他のアプリケーションで開くToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 元に戻す;
		private System.Windows.Forms.ToolStripMenuItem コピーToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem ペーストToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem カットToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 名称変更ToolStripMenuItem;
		private System.Windows.Forms.CheckBox continuousPlayCheckBox;
		private System.Windows.Forms.SplitContainer splitContainer2;
		private System.Windows.Forms.ListBox playListBox;
		public System.Windows.Forms.WebBrowser playerWebBrowser;
		private System.Windows.Forms.SplitContainer splitContainer3;
		private System.Windows.Forms.ToolStripMenuItem 再生ToolStripMenuItem;
		private System.Windows.Forms.Button playListRedoroe;
		private System.Windows.Forms.Button upDirButton;
		private System.Windows.Forms.Panel progresPanel;
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.Label ProgressTitolLabel;
		private System.Windows.Forms.Label targetCountLabel;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label progCountLabel;
		private System.Windows.Forms.Label ProgressMaxLabel;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label prgMessageLabel;
		private System.Windows.Forms.Label plTotalLabel;
		private System.Windows.Forms.Label plPosisionLabel;
		private System.Windows.Forms.Button plNextBbutton;
		private System.Windows.Forms.Button plRewButton;
		private System.Windows.Forms.Label parentPathLabel;
		private System.Windows.Forms.Label grarnPathLabel;
		private System.Windows.Forms.ContextMenuStrip PlayListContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem ファイルブラウザで選択;
	}
}


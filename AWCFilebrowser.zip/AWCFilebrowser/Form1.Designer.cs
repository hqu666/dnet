﻿namespace file_tree_clock_web1
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.ListViewGroup listViewGroup7 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            this.fileTree = new System.Windows.Forms.TreeView();
            this.fileTreeContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.titolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.フォルダ作成ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.名称変更ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.カットToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.コピーToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ペーストToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.削除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.元に戻す = new System.Windows.Forms.ToolStripMenuItem();
            this.このファイルを再生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.他のアプリケーションで開くToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.再生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.プレイリストに追加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.プレイリストを作成ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.videoFT2PLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.audioFT2PLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.通常サイズに戻すToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.lastWriteTime = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.fileLength = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.creationTime = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lastAccessTime = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rExtension = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.passNameLabel = new System.Windows.Forms.Label();
            this.fileNameLabel = new System.Windows.Forms.Label();
            this.baseSplitContainer = new System.Windows.Forms.SplitContainer();
            this.FileBrowserSplitContainer = new System.Windows.Forms.SplitContainer();
            this.FileBrowserCenterSplitContainer = new System.Windows.Forms.SplitContainer();
            this.FileViewBodySplitContainer = new System.Windows.Forms.SplitContainer();
            this.FilelistView = new System.Windows.Forms.ListView();
            this.NameColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SizeColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.UpDateColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.continuousPlayCheckBox = new System.Windows.Forms.CheckBox();
            this.mineType = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.typeName = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.viewSplitContainer = new System.Windows.Forms.SplitContainer();
            this.PlayListsplitContainer = new System.Windows.Forms.SplitContainer();
            this.PlayListTopSplitContainer = new System.Windows.Forms.SplitContainer();
            this.PlaylistComboBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.playListBox = new System.Windows.Forms.ListBox();
            this.grarnPathLabel = new System.Windows.Forms.TextBox();
            this.parentPathLabel = new System.Windows.Forms.TextBox();
            this.plTotalLabel = new System.Windows.Forms.Label();
            this.plPosisionLabel = new System.Windows.Forms.Label();
            this.MediaPlayerSplitContainer = new System.Windows.Forms.SplitContainer();
            this.MediaPlayerPanel = new System.Windows.Forms.Panel();
            this.progresPanel = new System.Windows.Forms.Panel();
            this.prgMessageLabel = new System.Windows.Forms.Label();
            this.ProgressMaxLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.targetCountLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.progCountLabel = new System.Windows.Forms.Label();
            this.ProgressTitolLabel = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.MediaControlPanel = new System.Windows.Forms.Panel();
            this.plNextBbutton = new System.Windows.Forms.Button();
            this.plRewButton = new System.Windows.Forms.Button();
            this.PlayPouseButton = new System.Windows.Forms.Button();
            this.VolLabel = new System.Windows.Forms.Label();
            this.EndTime = new System.Windows.Forms.Label();
            this.CarentTime = new System.Windows.Forms.Label();
            this.PlayTitolLabel = new System.Windows.Forms.Label();
            this.VolBar = new System.Windows.Forms.TrackBar();
            this.MediaPositionTrackBar = new System.Windows.Forms.TrackBar();
            this.PlayListContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ファイルブラウザで選択plToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.削除plToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.他のアプリケーションで開くplToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.エクスプローラーで開くplToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.通常サイズに戻すplToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ListContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.プレイリスト表示LCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.上の階層をリストアップLCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.読めないファイルを削除LCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.他のリストに結合LCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.先頭に挿入LCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.末尾に追加LCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.リストファイル選択LCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CurrentPositionTimer = new System.Windows.Forms.Timer(this.components);
            this.fileTreeContextMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.baseSplitContainer)).BeginInit();
            this.baseSplitContainer.Panel1.SuspendLayout();
            this.baseSplitContainer.Panel2.SuspendLayout();
            this.baseSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FileBrowserSplitContainer)).BeginInit();
            this.FileBrowserSplitContainer.Panel1.SuspendLayout();
            this.FileBrowserSplitContainer.Panel2.SuspendLayout();
            this.FileBrowserSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FileBrowserCenterSplitContainer)).BeginInit();
            this.FileBrowserCenterSplitContainer.Panel1.SuspendLayout();
            this.FileBrowserCenterSplitContainer.Panel2.SuspendLayout();
            this.FileBrowserCenterSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FileViewBodySplitContainer)).BeginInit();
            this.FileViewBodySplitContainer.Panel1.SuspendLayout();
            this.FileViewBodySplitContainer.Panel2.SuspendLayout();
            this.FileViewBodySplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewSplitContainer)).BeginInit();
            this.viewSplitContainer.Panel1.SuspendLayout();
            this.viewSplitContainer.Panel2.SuspendLayout();
            this.viewSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayListsplitContainer)).BeginInit();
            this.PlayListsplitContainer.Panel1.SuspendLayout();
            this.PlayListsplitContainer.Panel2.SuspendLayout();
            this.PlayListsplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayListTopSplitContainer)).BeginInit();
            this.PlayListTopSplitContainer.Panel1.SuspendLayout();
            this.PlayListTopSplitContainer.Panel2.SuspendLayout();
            this.PlayListTopSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MediaPlayerSplitContainer)).BeginInit();
            this.MediaPlayerSplitContainer.Panel1.SuspendLayout();
            this.MediaPlayerSplitContainer.Panel2.SuspendLayout();
            this.MediaPlayerSplitContainer.SuspendLayout();
            this.MediaPlayerPanel.SuspendLayout();
            this.progresPanel.SuspendLayout();
            this.MediaControlPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VolBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MediaPositionTrackBar)).BeginInit();
            this.PlayListContextMenuStrip.SuspendLayout();
            this.ListContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // fileTree
            // 
            this.fileTree.AllowDrop = true;
            this.fileTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fileTree.Location = new System.Drawing.Point(0, 0);
            this.fileTree.Name = "fileTree";
            this.fileTree.Size = new System.Drawing.Size(199, 575);
            this.fileTree.TabIndex = 7;
            this.fileTree.DoubleClick += new System.EventHandler(this.FileTree_DoubleClick);
            this.fileTree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FileTree_KeyUp);
            this.fileTree.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FilelistBoxMouseUp);
            // 
            // fileTreeContextMenuStrip
            // 
            this.fileTreeContextMenuStrip.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fileTreeContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.titolToolStripMenuItem,
            this.フォルダ作成ToolStripMenuItem,
            this.名称変更ToolStripMenuItem,
            this.カットToolStripMenuItem,
            this.コピーToolStripMenuItem,
            this.ペーストToolStripMenuItem,
            this.削除ToolStripMenuItem,
            this.元に戻す,
            this.このファイルを再生ToolStripMenuItem,
            this.他のアプリケーションで開くToolStripMenuItem,
            this.再生ToolStripMenuItem,
            this.プレイリストに追加ToolStripMenuItem,
            this.プレイリストを作成ToolStripMenuItem,
            this.通常サイズに戻すToolStripMenuItem});
            this.fileTreeContextMenuStrip.Name = "contextMenuStrip1";
            this.fileTreeContextMenuStrip.Size = new System.Drawing.Size(208, 312);
            this.fileTreeContextMenuStrip.Text = "Titol";
            this.fileTreeContextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.PlaylistAddMenuStrip_Opening);
            this.fileTreeContextMenuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.FileTreeContextMenuStrip_ItemClicked);
            // 
            // titolToolStripMenuItem
            // 
            this.titolToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.titolToolStripMenuItem.Enabled = false;
            this.titolToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.titolToolStripMenuItem.Name = "titolToolStripMenuItem";
            this.titolToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.titolToolStripMenuItem.Text = "titol";
            // 
            // フォルダ作成ToolStripMenuItem
            // 
            this.フォルダ作成ToolStripMenuItem.Name = "フォルダ作成ToolStripMenuItem";
            this.フォルダ作成ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.N)));
            this.フォルダ作成ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.フォルダ作成ToolStripMenuItem.Text = "フォルダ作成";
            // 
            // 名称変更ToolStripMenuItem
            // 
            this.名称変更ToolStripMenuItem.Name = "名称変更ToolStripMenuItem";
            this.名称変更ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.名称変更ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.名称変更ToolStripMenuItem.Text = "名称変更";
            // 
            // カットToolStripMenuItem
            // 
            this.カットToolStripMenuItem.Name = "カットToolStripMenuItem";
            this.カットToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.カットToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.カットToolStripMenuItem.Text = "カット";
            // 
            // コピーToolStripMenuItem
            // 
            this.コピーToolStripMenuItem.Name = "コピーToolStripMenuItem";
            this.コピーToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.コピーToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.コピーToolStripMenuItem.Text = "コピー";
            // 
            // ペーストToolStripMenuItem
            // 
            this.ペーストToolStripMenuItem.Name = "ペーストToolStripMenuItem";
            this.ペーストToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.ペーストToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.ペーストToolStripMenuItem.Text = "ペースト";
            // 
            // 削除ToolStripMenuItem
            // 
            this.削除ToolStripMenuItem.Name = "削除ToolStripMenuItem";
            this.削除ToolStripMenuItem.ShortcutKeyDisplayString = "Delete";
            this.削除ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.削除ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.削除ToolStripMenuItem.Text = "削除";
            // 
            // 元に戻す
            // 
            this.元に戻す.Name = "元に戻す";
            this.元に戻す.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.元に戻す.Size = new System.Drawing.Size(207, 22);
            this.元に戻す.Text = "元に戻す";
            this.元に戻す.Visible = false;
            // 
            // このファイルを再生ToolStripMenuItem
            // 
            this.このファイルを再生ToolStripMenuItem.Name = "このファイルを再生ToolStripMenuItem";
            this.このファイルを再生ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.このファイルを再生ToolStripMenuItem.Text = "このファイルを再生";
            // 
            // 他のアプリケーションで開くToolStripMenuItem
            // 
            this.他のアプリケーションで開くToolStripMenuItem.Name = "他のアプリケーションで開くToolStripMenuItem";
            this.他のアプリケーションで開くToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.他のアプリケーションで開くToolStripMenuItem.Text = "他のアプリケーションで開く";
            // 
            // 再生ToolStripMenuItem
            // 
            this.再生ToolStripMenuItem.Name = "再生ToolStripMenuItem";
            this.再生ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.再生ToolStripMenuItem.Text = "再生";
            // 
            // プレイリストに追加ToolStripMenuItem
            // 
            this.プレイリストに追加ToolStripMenuItem.Name = "プレイリストに追加ToolStripMenuItem";
            this.プレイリストに追加ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.プレイリストに追加ToolStripMenuItem.Text = "プレイリストに追加";
            // 
            // プレイリストを作成ToolStripMenuItem
            // 
            this.プレイリストを作成ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.videoFT2PLToolStripMenuItem,
            this.audioFT2PLToolStripMenuItem});
            this.プレイリストを作成ToolStripMenuItem.Name = "プレイリストを作成ToolStripMenuItem";
            this.プレイリストを作成ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.プレイリストを作成ToolStripMenuItem.Text = "プレイリストを作成";
            // 
            // videoFT2PLToolStripMenuItem
            // 
            this.videoFT2PLToolStripMenuItem.Name = "videoFT2PLToolStripMenuItem";
            this.videoFT2PLToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.videoFT2PLToolStripMenuItem.Text = "video";
            this.videoFT2PLToolStripMenuItem.Click += new System.EventHandler(this.PlayListMakeContextMenuStrip_SubMenuClick);
            // 
            // audioFT2PLToolStripMenuItem
            // 
            this.audioFT2PLToolStripMenuItem.Name = "audioFT2PLToolStripMenuItem";
            this.audioFT2PLToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.audioFT2PLToolStripMenuItem.Text = "audio";
            this.audioFT2PLToolStripMenuItem.Click += new System.EventHandler(this.PlayListMakeContextMenuStrip_SubMenuClick);
            // 
            // 通常サイズに戻すToolStripMenuItem
            // 
            this.通常サイズに戻すToolStripMenuItem.Name = "通常サイズに戻すToolStripMenuItem";
            this.通常サイズに戻すToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.通常サイズに戻すToolStripMenuItem.Text = "通常サイズに戻す";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 11;
            this.label2.Text = "更新日";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lastWriteTime
            // 
            this.lastWriteTime.AutoSize = true;
            this.lastWriteTime.Location = new System.Drawing.Point(50, 11);
            this.lastWriteTime.Name = "lastWriteTime";
            this.lastWriteTime.Size = new System.Drawing.Size(119, 12);
            this.lastWriteTime.TabIndex = 12;
            this.lastWriteTime.Text = "2999年12月31日 23:59";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "ファイルサイズ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fileLength
            // 
            this.fileLength.AutoSize = true;
            this.fileLength.Location = new System.Drawing.Point(74, 63);
            this.fileLength.Name = "fileLength";
            this.fileLength.Size = new System.Drawing.Size(95, 12);
            this.fileLength.TabIndex = 14;
            this.fileLength.Text = "999999999999999";
            this.fileLength.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 15;
            this.label4.Text = "作成日";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // creationTime
            // 
            this.creationTime.AutoSize = true;
            this.creationTime.Location = new System.Drawing.Point(50, 47);
            this.creationTime.Name = "creationTime";
            this.creationTime.Size = new System.Drawing.Size(119, 12);
            this.creationTime.TabIndex = 16;
            this.creationTime.Text = "2999年12月31日 23:59";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 17;
            this.label5.Text = "アクセス";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lastAccessTime
            // 
            this.lastAccessTime.AutoSize = true;
            this.lastAccessTime.Location = new System.Drawing.Point(50, 29);
            this.lastAccessTime.Name = "lastAccessTime";
            this.lastAccessTime.Size = new System.Drawing.Size(119, 12);
            this.lastAccessTime.TabIndex = 18;
            this.lastAccessTime.Text = "2999年12月31日 23:59";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(175, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 19;
            this.label6.Text = "拡張子";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rExtension
            // 
            this.rExtension.AutoSize = true;
            this.rExtension.Location = new System.Drawing.Point(222, 29);
            this.rExtension.Name = "rExtension";
            this.rExtension.Size = new System.Drawing.Size(0, 12);
            this.rExtension.TabIndex = 20;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "hd_icon.png");
            this.imageList1.Images.SetKeyName(1, "folder_close_icon.png");
            this.imageList1.Images.SetKeyName(2, "docment_icon.png");
            this.imageList1.Images.SetKeyName(3, "move_icon.png");
            this.imageList1.Images.SetKeyName(4, "pict_icon.png");
            this.imageList1.Images.SetKeyName(5, "music_icon.png");
            this.imageList1.Images.SetKeyName(6, "desktop_icon.png");
            this.imageList1.Images.SetKeyName(7, "pc_icon.png");
            this.imageList1.Images.SetKeyName(8, "folder_close_icon.png");
            this.imageList1.Images.SetKeyName(9, "phone_icon.png");
            this.imageList1.Images.SetKeyName(10, "hd_sys_icon.png");
            this.imageList1.Images.SetKeyName(11, "Very-Basic-Menu-icon");
            // 
            // passNameLabel
            // 
            this.passNameLabel.AutoSize = true;
            this.passNameLabel.Location = new System.Drawing.Point(5, 5);
            this.passNameLabel.Name = "passNameLabel";
            this.passNameLabel.Size = new System.Drawing.Size(0, 12);
            this.passNameLabel.TabIndex = 21;
            this.passNameLabel.Click += new System.EventHandler(this.PassNameLabel_Click);
            // 
            // fileNameLabel
            // 
            this.fileNameLabel.AutoSize = true;
            this.fileNameLabel.Location = new System.Drawing.Point(5, 25);
            this.fileNameLabel.Name = "fileNameLabel";
            this.fileNameLabel.Size = new System.Drawing.Size(41, 12);
            this.fileNameLabel.TabIndex = 22;
            this.fileNameLabel.Text = "未選択";
            // 
            // baseSplitContainer
            // 
            this.baseSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.baseSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.baseSplitContainer.Name = "baseSplitContainer";
            // 
            // baseSplitContainer.Panel1
            // 
            this.baseSplitContainer.Panel1.Controls.Add(this.FileBrowserSplitContainer);
            this.baseSplitContainer.Panel1MinSize = 0;
            // 
            // baseSplitContainer.Panel2
            // 
            this.baseSplitContainer.Panel2.AutoScroll = true;
            this.baseSplitContainer.Panel2.Controls.Add(this.viewSplitContainer);
            this.baseSplitContainer.Size = new System.Drawing.Size(1544, 712);
            this.baseSplitContainer.SplitterDistance = 472;
            this.baseSplitContainer.TabIndex = 27;
            // 
            // FileBrowserSplitContainer
            // 
            this.FileBrowserSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FileBrowserSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.FileBrowserSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.FileBrowserSplitContainer.Name = "FileBrowserSplitContainer";
            this.FileBrowserSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // FileBrowserSplitContainer.Panel1
            // 
            this.FileBrowserSplitContainer.Panel1.Controls.Add(this.fileNameLabel);
            this.FileBrowserSplitContainer.Panel1.Controls.Add(this.passNameLabel);
            // 
            // FileBrowserSplitContainer.Panel2
            // 
            this.FileBrowserSplitContainer.Panel2.Controls.Add(this.FileBrowserCenterSplitContainer);
            this.FileBrowserSplitContainer.Size = new System.Drawing.Size(472, 712);
            this.FileBrowserSplitContainer.SplitterDistance = 47;
            this.FileBrowserSplitContainer.TabIndex = 0;
            // 
            // FileBrowserCenterSplitContainer
            // 
            this.FileBrowserCenterSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FileBrowserCenterSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.FileBrowserCenterSplitContainer.IsSplitterFixed = true;
            this.FileBrowserCenterSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.FileBrowserCenterSplitContainer.Name = "FileBrowserCenterSplitContainer";
            this.FileBrowserCenterSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // FileBrowserCenterSplitContainer.Panel1
            // 
            this.FileBrowserCenterSplitContainer.Panel1.AutoScroll = true;
            this.FileBrowserCenterSplitContainer.Panel1.Controls.Add(this.FileViewBodySplitContainer);
            // 
            // FileBrowserCenterSplitContainer.Panel2
            // 
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.continuousPlayCheckBox);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.mineType);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.label8);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.typeName);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.label7);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.lastAccessTime);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.rExtension);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.label5);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.fileLength);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.creationTime);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.label3);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.label6);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.lastWriteTime);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.label4);
            this.FileBrowserCenterSplitContainer.Panel2.Controls.Add(this.label2);
            this.FileBrowserCenterSplitContainer.Panel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.FileBrowserCenterSplitContainer.Size = new System.Drawing.Size(472, 661);
            this.FileBrowserCenterSplitContainer.SplitterDistance = 575;
            this.FileBrowserCenterSplitContainer.TabIndex = 0;
            // 
            // FileViewBodySplitContainer
            // 
            this.FileViewBodySplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FileViewBodySplitContainer.Location = new System.Drawing.Point(0, 0);
            this.FileViewBodySplitContainer.Name = "FileViewBodySplitContainer";
            // 
            // FileViewBodySplitContainer.Panel1
            // 
            this.FileViewBodySplitContainer.Panel1.Controls.Add(this.fileTree);
            // 
            // FileViewBodySplitContainer.Panel2
            // 
            this.FileViewBodySplitContainer.Panel2.Controls.Add(this.FilelistView);
            this.FileViewBodySplitContainer.Size = new System.Drawing.Size(472, 575);
            this.FileViewBodySplitContainer.SplitterDistance = 199;
            this.FileViewBodySplitContainer.TabIndex = 8;
            // 
            // FilelistView
            // 
            this.FilelistView.AccessibleRole = System.Windows.Forms.AccessibleRole.ListItem;
            this.FilelistView.AllowDrop = true;
            this.FilelistView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.NameColumnHeader,
            this.SizeColumnHeader,
            this.UpDateColumnHeader});
            this.FilelistView.Dock = System.Windows.Forms.DockStyle.Fill;
            listViewGroup7.Header = "ListViewGroup";
            listViewGroup7.Name = "listViewGroup1";
            this.FilelistView.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup7});
            this.FilelistView.HideSelection = false;
            this.FilelistView.LabelEdit = true;
            this.FilelistView.Location = new System.Drawing.Point(0, 0);
            this.FilelistView.Name = "FilelistView";
            this.FilelistView.ShowGroups = false;
            this.FilelistView.Size = new System.Drawing.Size(269, 575);
            this.FilelistView.TabIndex = 0;
            this.FilelistView.UseCompatibleStateImageBehavior = false;
            this.FilelistView.View = System.Windows.Forms.View.Details;
            this.FilelistView.BeforeLabelEdit += new System.Windows.Forms.LabelEditEventHandler(this.FilelistView_BeforeLabelEdit);
            this.FilelistView.QueryContinueDrag += new System.Windows.Forms.QueryContinueDragEventHandler(this.FilelistView_QueryContinueDrag);
            this.FilelistView.DoubleClick += new System.EventHandler(this.FilelistView_DoubleClick);
            this.FilelistView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FilelistView_KeyUp);
            this.FilelistView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FilelistView_MouseUp);
            // 
            // NameColumnHeader
            // 
            this.NameColumnHeader.Text = "名前";
            this.NameColumnHeader.Width = 174;
            // 
            // SizeColumnHeader
            // 
            this.SizeColumnHeader.Text = "サイズ";
            this.SizeColumnHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SizeColumnHeader.Width = 80;
            // 
            // UpDateColumnHeader
            // 
            this.UpDateColumnHeader.Text = "更新日";
            this.UpDateColumnHeader.Width = 156;
            // 
            // continuousPlayCheckBox
            // 
            this.continuousPlayCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.continuousPlayCheckBox.AutoSize = true;
            this.continuousPlayCheckBox.Location = new System.Drawing.Point(394, 7);
            this.continuousPlayCheckBox.Name = "continuousPlayCheckBox";
            this.continuousPlayCheckBox.Size = new System.Drawing.Size(72, 16);
            this.continuousPlayCheckBox.TabIndex = 26;
            this.continuousPlayCheckBox.Text = "連続再生";
            this.continuousPlayCheckBox.UseVisualStyleBackColor = true;
            this.continuousPlayCheckBox.Click += new System.EventHandler(this.ContinuousPlayCheckBox_CheckedChanged);
            // 
            // mineType
            // 
            this.mineType.AutoSize = true;
            this.mineType.Location = new System.Drawing.Point(217, 63);
            this.mineType.Name = "mineType";
            this.mineType.Size = new System.Drawing.Size(62, 12);
            this.mineType.TabIndex = 24;
            this.mineType.Text = "MIME Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(178, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 12);
            this.label8.TabIndex = 23;
            this.label8.Text = "MIME";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // typeName
            // 
            this.typeName.AutoSize = true;
            this.typeName.Location = new System.Drawing.Point(217, 46);
            this.typeName.Name = "typeName";
            this.typeName.Size = new System.Drawing.Size(60, 12);
            this.typeName.TabIndex = 22;
            this.typeName.Text = "application";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(184, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 21;
            this.label7.Text = "分類";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // viewSplitContainer
            // 
            this.viewSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.viewSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.viewSplitContainer.Name = "viewSplitContainer";
            // 
            // viewSplitContainer.Panel1
            // 
            this.viewSplitContainer.Panel1.Controls.Add(this.PlayListsplitContainer);
            // 
            // viewSplitContainer.Panel2
            // 
            this.viewSplitContainer.Panel2.AllowDrop = true;
            this.viewSplitContainer.Panel2.AutoScroll = true;
            this.viewSplitContainer.Panel2.Controls.Add(this.MediaPlayerSplitContainer);
            this.viewSplitContainer.Size = new System.Drawing.Size(1068, 712);
            this.viewSplitContainer.SplitterDistance = 235;
            this.viewSplitContainer.TabIndex = 26;
            // 
            // PlayListsplitContainer
            // 
            this.PlayListsplitContainer.BackColor = System.Drawing.SystemColors.Control;
            this.PlayListsplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PlayListsplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.PlayListsplitContainer.ForeColor = System.Drawing.SystemColors.Control;
            this.PlayListsplitContainer.IsSplitterFixed = true;
            this.PlayListsplitContainer.Location = new System.Drawing.Point(0, 0);
            this.PlayListsplitContainer.Name = "PlayListsplitContainer";
            this.PlayListsplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // PlayListsplitContainer.Panel1
            // 
            this.PlayListsplitContainer.Panel1.AutoScroll = true;
            this.PlayListsplitContainer.Panel1.BackColor = System.Drawing.SystemColors.Control;
            this.PlayListsplitContainer.Panel1.Controls.Add(this.PlayListTopSplitContainer);
            // 
            // PlayListsplitContainer.Panel2
            // 
            this.PlayListsplitContainer.Panel2.Controls.Add(this.grarnPathLabel);
            this.PlayListsplitContainer.Panel2.Controls.Add(this.parentPathLabel);
            this.PlayListsplitContainer.Panel2.Controls.Add(this.plTotalLabel);
            this.PlayListsplitContainer.Panel2.Controls.Add(this.plPosisionLabel);
            this.PlayListsplitContainer.Panel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.PlayListsplitContainer.Size = new System.Drawing.Size(235, 712);
            this.PlayListsplitContainer.SplitterDistance = 626;
            this.PlayListsplitContainer.TabIndex = 2;
            // 
            // PlayListTopSplitContainer
            // 
            this.PlayListTopSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PlayListTopSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.PlayListTopSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.PlayListTopSplitContainer.Name = "PlayListTopSplitContainer";
            this.PlayListTopSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // PlayListTopSplitContainer.Panel1
            // 
            this.PlayListTopSplitContainer.Panel1.Controls.Add(this.PlaylistComboBox);
            this.PlayListTopSplitContainer.Panel1.Controls.Add(this.label10);
            this.PlayListTopSplitContainer.Panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            // 
            // PlayListTopSplitContainer.Panel2
            // 
            this.PlayListTopSplitContainer.Panel2.Controls.Add(this.playListBox);
            this.PlayListTopSplitContainer.Panel2.Padding = new System.Windows.Forms.Padding(3);
            this.PlayListTopSplitContainer.Size = new System.Drawing.Size(235, 626);
            this.PlayListTopSplitContainer.SplitterDistance = 48;
            this.PlayListTopSplitContainer.TabIndex = 1;
            // 
            // PlaylistComboBox
            // 
            this.PlaylistComboBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PlaylistComboBox.FormattingEnabled = true;
            this.PlaylistComboBox.Location = new System.Drawing.Point(0, 28);
            this.PlaylistComboBox.Name = "PlaylistComboBox";
            this.PlaylistComboBox.Size = new System.Drawing.Size(235, 20);
            this.PlaylistComboBox.TabIndex = 1;
            this.PlaylistComboBox.SelectedIndexChanged += new System.EventHandler(this.PlaylistComboBox_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "選択しているリスト";
            // 
            // playListBox
            // 
            this.playListBox.AllowDrop = true;
            this.playListBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.playListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.playListBox.FormattingEnabled = true;
            this.playListBox.ItemHeight = 12;
            this.playListBox.Location = new System.Drawing.Point(3, 3);
            this.playListBox.Name = "playListBox";
            this.playListBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.playListBox.Size = new System.Drawing.Size(229, 568);
            this.playListBox.TabIndex = 0;
            this.playListBox.SelectedIndexChanged += new System.EventHandler(this.PlayListBox_Select);
            this.playListBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.PlayListBox_DragDrop);
            this.playListBox.DragEnter += new System.Windows.Forms.DragEventHandler(this.PlayListBox_DragEnter);
            this.playListBox.DragOver += new System.Windows.Forms.DragEventHandler(this.PlayListBox_DragOver);
            this.playListBox.DragLeave += new System.EventHandler(this.PlayListBox_DragLeave);
            this.playListBox.DoubleClick += new System.EventHandler(this.PlayListBox_Select);
            this.playListBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PlayListBox_KeyDown);
            this.playListBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PlayListBox_KeyUp);
            this.playListBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PlayListBox_MouseDown);
            this.playListBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PlayListBox_MouseMove);
            this.playListBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PlaylistBoxMouseUp);
            // 
            // grarnPathLabel
            // 
            this.grarnPathLabel.BackColor = System.Drawing.SystemColors.Control;
            this.grarnPathLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grarnPathLabel.Location = new System.Drawing.Point(3, 19);
            this.grarnPathLabel.Multiline = true;
            this.grarnPathLabel.Name = "grarnPathLabel";
            this.grarnPathLabel.ReadOnly = true;
            this.grarnPathLabel.Size = new System.Drawing.Size(230, 28);
            this.grarnPathLabel.TabIndex = 36;
            this.grarnPathLabel.Text = "grarnPath";
            // 
            // parentPathLabel
            // 
            this.parentPathLabel.BackColor = System.Drawing.SystemColors.Control;
            this.parentPathLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.parentPathLabel.Location = new System.Drawing.Point(3, 50);
            this.parentPathLabel.Multiline = true;
            this.parentPathLabel.Name = "parentPathLabel";
            this.parentPathLabel.ReadOnly = true;
            this.parentPathLabel.Size = new System.Drawing.Size(227, 28);
            this.parentPathLabel.TabIndex = 35;
            this.parentPathLabel.Text = "parentPath";
            // 
            // plTotalLabel
            // 
            this.plTotalLabel.AutoSize = true;
            this.plTotalLabel.Location = new System.Drawing.Point(190, 61);
            this.plTotalLabel.Name = "plTotalLabel";
            this.plTotalLabel.Size = new System.Drawing.Size(0, 12);
            this.plTotalLabel.TabIndex = 30;
            // 
            // plPosisionLabel
            // 
            this.plPosisionLabel.AutoSize = true;
            this.plPosisionLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.plPosisionLabel.Location = new System.Drawing.Point(3, 5);
            this.plPosisionLabel.Name = "plPosisionLabel";
            this.plPosisionLabel.Size = new System.Drawing.Size(76, 12);
            this.plPosisionLabel.TabIndex = 28;
            this.plPosisionLabel.Text = "posision/total";
            // 
            // MediaPlayerSplitContainer
            // 
            this.MediaPlayerSplitContainer.BackColor = System.Drawing.Color.Black;
            this.MediaPlayerSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MediaPlayerSplitContainer.ForeColor = System.Drawing.Color.Black;
            this.MediaPlayerSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.MediaPlayerSplitContainer.Name = "MediaPlayerSplitContainer";
            this.MediaPlayerSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // MediaPlayerSplitContainer.Panel1
            // 
            this.MediaPlayerSplitContainer.Panel1.AccessibleName = "";
            this.MediaPlayerSplitContainer.Panel1.Controls.Add(this.MediaPlayerPanel);
            // 
            // MediaPlayerSplitContainer.Panel2
            // 
            this.MediaPlayerSplitContainer.Panel2.Controls.Add(this.MediaControlPanel);
            this.MediaPlayerSplitContainer.Size = new System.Drawing.Size(829, 712);
            this.MediaPlayerSplitContainer.SplitterDistance = 625;
            this.MediaPlayerSplitContainer.TabIndex = 0;
            // 
            // MediaPlayerPanel
            // 
            this.MediaPlayerPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MediaPlayerPanel.BackColor = System.Drawing.SystemColors.Control;
            this.MediaPlayerPanel.Controls.Add(this.progresPanel);
            this.MediaPlayerPanel.Location = new System.Drawing.Point(0, 0);
            this.MediaPlayerPanel.Name = "MediaPlayerPanel";
            this.MediaPlayerPanel.Size = new System.Drawing.Size(829, 625);
            this.MediaPlayerPanel.TabIndex = 0;
            // 
            // progresPanel
            // 
            this.progresPanel.BackColor = System.Drawing.SystemColors.Window;
            this.progresPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.progresPanel.Controls.Add(this.prgMessageLabel);
            this.progresPanel.Controls.Add(this.ProgressMaxLabel);
            this.progresPanel.Controls.Add(this.label1);
            this.progresPanel.Controls.Add(this.targetCountLabel);
            this.progresPanel.Controls.Add(this.label9);
            this.progresPanel.Controls.Add(this.progCountLabel);
            this.progresPanel.Controls.Add(this.ProgressTitolLabel);
            this.progresPanel.Controls.Add(this.progressBar1);
            this.progresPanel.Location = new System.Drawing.Point(21, 67);
            this.progresPanel.Name = "progresPanel";
            this.progresPanel.Size = new System.Drawing.Size(796, 79);
            this.progresPanel.TabIndex = 4;
            this.progresPanel.Visible = false;
            // 
            // prgMessageLabel
            // 
            this.prgMessageLabel.AutoSize = true;
            this.prgMessageLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.prgMessageLabel.Location = new System.Drawing.Point(4, 61);
            this.prgMessageLabel.Name = "prgMessageLabel";
            this.prgMessageLabel.Size = new System.Drawing.Size(66, 12);
            this.prgMessageLabel.TabIndex = 18;
            this.prgMessageLabel.Text = "リストアップ中";
            // 
            // ProgressMaxLabel
            // 
            this.ProgressMaxLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ProgressMaxLabel.AutoSize = true;
            this.ProgressMaxLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ProgressMaxLabel.Location = new System.Drawing.Point(697, 39);
            this.ProgressMaxLabel.Name = "ProgressMaxLabel";
            this.ProgressMaxLabel.Size = new System.Drawing.Size(59, 12);
            this.ProgressMaxLabel.TabIndex = 17;
            this.ProgressMaxLabel.Text = "000000000";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(1072, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 16;
            this.label1.Text = "/";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // targetCountLabel
            // 
            this.targetCountLabel.AutoSize = true;
            this.targetCountLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.targetCountLabel.Location = new System.Drawing.Point(236, 39);
            this.targetCountLabel.Name = "targetCountLabel";
            this.targetCountLabel.Size = new System.Drawing.Size(59, 12);
            this.targetCountLabel.TabIndex = 15;
            this.targetCountLabel.Text = "000000000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(116, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 14;
            this.label9.Text = ">対象>";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // progCountLabel
            // 
            this.progCountLabel.AutoSize = true;
            this.progCountLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.progCountLabel.Location = new System.Drawing.Point(4, 39);
            this.progCountLabel.Name = "progCountLabel";
            this.progCountLabel.Size = new System.Drawing.Size(59, 12);
            this.progCountLabel.TabIndex = 13;
            this.progCountLabel.Text = "000000000";
            this.progCountLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ProgressTitolLabel
            // 
            this.ProgressTitolLabel.AutoSize = true;
            this.ProgressTitolLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ProgressTitolLabel.Location = new System.Drawing.Point(5, 4);
            this.ProgressTitolLabel.Name = "ProgressTitolLabel";
            this.ProgressTitolLabel.Size = new System.Drawing.Size(73, 12);
            this.ProgressTitolLabel.TabIndex = 4;
            this.ProgressTitolLabel.Text = "ProgressTitol";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(3, 19);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(786, 17);
            this.progressBar1.TabIndex = 3;
            // 
            // MediaControlPanel
            // 
            this.MediaControlPanel.BackColor = System.Drawing.Color.Black;
            this.MediaControlPanel.Controls.Add(this.plNextBbutton);
            this.MediaControlPanel.Controls.Add(this.plRewButton);
            this.MediaControlPanel.Controls.Add(this.PlayPouseButton);
            this.MediaControlPanel.Controls.Add(this.VolLabel);
            this.MediaControlPanel.Controls.Add(this.EndTime);
            this.MediaControlPanel.Controls.Add(this.CarentTime);
            this.MediaControlPanel.Controls.Add(this.PlayTitolLabel);
            this.MediaControlPanel.Controls.Add(this.VolBar);
            this.MediaControlPanel.Controls.Add(this.MediaPositionTrackBar);
            this.MediaControlPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.MediaControlPanel.Location = new System.Drawing.Point(0, 0);
            this.MediaControlPanel.Name = "MediaControlPanel";
            this.MediaControlPanel.Size = new System.Drawing.Size(829, 83);
            this.MediaControlPanel.TabIndex = 0;
            // 
            // plNextBbutton
            // 
            this.plNextBbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.plNextBbutton.BackColor = System.Drawing.Color.Transparent;
            this.plNextBbutton.BackgroundImage = global::AWSFileBroeser.Properties.Resources.ffbtn;
            this.plNextBbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.plNextBbutton.FlatAppearance.BorderSize = 0;
            this.plNextBbutton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.plNextBbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.plNextBbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.plNextBbutton.Location = new System.Drawing.Point(601, 43);
            this.plNextBbutton.Margin = new System.Windows.Forms.Padding(0);
            this.plNextBbutton.Name = "plNextBbutton";
            this.plNextBbutton.Size = new System.Drawing.Size(40, 40);
            this.plNextBbutton.TabIndex = 40;
            this.plNextBbutton.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.plNextBbutton.UseVisualStyleBackColor = false;
            this.plNextBbutton.Click += new System.EventHandler(this.PlNextBbutton_Click);
            // 
            // plRewButton
            // 
            this.plRewButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.plRewButton.BackColor = System.Drawing.Color.Transparent;
            this.plRewButton.BackgroundImage = global::AWSFileBroeser.Properties.Resources.rewbtn;
            this.plRewButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.plRewButton.FlatAppearance.BorderSize = 0;
            this.plRewButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.plRewButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.plRewButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.plRewButton.Location = new System.Drawing.Point(190, 48);
            this.plRewButton.Margin = new System.Windows.Forms.Padding(0);
            this.plRewButton.Name = "plRewButton";
            this.plRewButton.Size = new System.Drawing.Size(30, 30);
            this.plRewButton.TabIndex = 39;
            this.plRewButton.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.plRewButton.UseVisualStyleBackColor = false;
            this.plRewButton.Click += new System.EventHandler(this.PlRewButton_Click);
            // 
            // PlayPouseButton
            // 
            this.PlayPouseButton.BackColor = System.Drawing.Color.Transparent;
            this.PlayPouseButton.BackgroundImage = global::AWSFileBroeser.Properties.Resources.pl_r_btn;
            this.PlayPouseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PlayPouseButton.FlatAppearance.BorderSize = 0;
            this.PlayPouseButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.PlayPouseButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.PlayPouseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PlayPouseButton.Location = new System.Drawing.Point(0, 0);
            this.PlayPouseButton.Margin = new System.Windows.Forms.Padding(1);
            this.PlayPouseButton.Name = "PlayPouseButton";
            this.PlayPouseButton.Size = new System.Drawing.Size(80, 80);
            this.PlayPouseButton.TabIndex = 38;
            this.PlayPouseButton.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.PlayPouseButton.UseVisualStyleBackColor = false;
            this.PlayPouseButton.Click += new System.EventHandler(this.PlayPouseButton_Click);
            // 
            // VolLabel
            // 
            this.VolLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.VolLabel.AutoSize = true;
            this.VolLabel.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.VolLabel.ForeColor = System.Drawing.Color.White;
            this.VolLabel.Location = new System.Drawing.Point(754, 51);
            this.VolLabel.Name = "VolLabel";
            this.VolLabel.Size = new System.Drawing.Size(32, 16);
            this.VolLabel.TabIndex = 36;
            this.VolLabel.Text = "100";
            this.VolLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.VolLabel.Click += new System.EventHandler(this.VolLabel_Click);
            // 
            // EndTime
            // 
            this.EndTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EndTime.AutoSize = true;
            this.EndTime.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.EndTime.ForeColor = System.Drawing.Color.White;
            this.EndTime.Location = new System.Drawing.Point(644, 44);
            this.EndTime.Name = "EndTime";
            this.EndTime.Size = new System.Drawing.Size(104, 24);
            this.EndTime.TabIndex = 35;
            this.EndTime.Text = "000:00:00";
            this.EndTime.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // CarentTime
            // 
            this.CarentTime.AutoSize = true;
            this.CarentTime.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.CarentTime.ForeColor = System.Drawing.Color.White;
            this.CarentTime.Location = new System.Drawing.Point(83, 46);
            this.CarentTime.Name = "CarentTime";
            this.CarentTime.Size = new System.Drawing.Size(104, 24);
            this.CarentTime.TabIndex = 34;
            this.CarentTime.Text = "000:00:00";
            // 
            // PlayTitolLabel
            // 
            this.PlayTitolLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PlayTitolLabel.Font = new System.Drawing.Font("MS UI Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.PlayTitolLabel.ForeColor = System.Drawing.Color.White;
            this.PlayTitolLabel.Location = new System.Drawing.Point(221, 47);
            this.PlayTitolLabel.Margin = new System.Windows.Forms.Padding(0);
            this.PlayTitolLabel.Name = "PlayTitolLabel";
            this.PlayTitolLabel.Size = new System.Drawing.Size(380, 33);
            this.PlayTitolLabel.TabIndex = 33;
            this.PlayTitolLabel.Text = "PlayTitol\r\nLabel";
            // 
            // VolBar
            // 
            this.VolBar.Dock = System.Windows.Forms.DockStyle.Right;
            this.VolBar.Location = new System.Drawing.Point(784, 0);
            this.VolBar.Maximum = 100;
            this.VolBar.Name = "VolBar";
            this.VolBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.VolBar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.VolBar.RightToLeftLayout = true;
            this.VolBar.Size = new System.Drawing.Size(45, 83);
            this.VolBar.TabIndex = 3;
            this.VolBar.TickFrequency = 50;
            this.VolBar.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.VolBar.Scroll += new System.EventHandler(this.VolBar_Scroll);
            // 
            // MediaPositionTrackBar
            // 
            this.MediaPositionTrackBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MediaPositionTrackBar.BackColor = System.Drawing.Color.Black;
            this.MediaPositionTrackBar.Location = new System.Drawing.Point(81, 2);
            this.MediaPositionTrackBar.Maximum = 100;
            this.MediaPositionTrackBar.Name = "MediaPositionTrackBar";
            this.MediaPositionTrackBar.Size = new System.Drawing.Size(697, 45);
            this.MediaPositionTrackBar.TabIndex = 1;
            this.MediaPositionTrackBar.TickFrequency = 10;
            this.MediaPositionTrackBar.Scroll += new System.EventHandler(this.MediaPositionTrackBar_Scroll);
            // 
            // PlayListContextMenuStrip
            // 
            this.PlayListContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルブラウザで選択plToolStripMenuItem,
            this.削除plToolStripMenuItem,
            this.他のアプリケーションで開くplToolStripMenuItem,
            this.エクスプローラーで開くplToolStripMenuItem,
            this.通常サイズに戻すplToolStripMenuItem});
            this.PlayListContextMenuStrip.Name = "PlayListContextMenuStrip";
            this.PlayListContextMenuStrip.Size = new System.Drawing.Size(195, 114);
            this.PlayListContextMenuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.PlayListContextMenuStrip_ItemClicked);
            // 
            // ファイルブラウザで選択plToolStripMenuItem
            // 
            this.ファイルブラウザで選択plToolStripMenuItem.Name = "ファイルブラウザで選択plToolStripMenuItem";
            this.ファイルブラウザで選択plToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.ファイルブラウザで選択plToolStripMenuItem.Text = "ファイルブラウザで選択";
            // 
            // 削除plToolStripMenuItem
            // 
            this.削除plToolStripMenuItem.Name = "削除plToolStripMenuItem";
            this.削除plToolStripMenuItem.ShortcutKeyDisplayString = "Delete";
            this.削除plToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.削除plToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.削除plToolStripMenuItem.Text = "削除";
            // 
            // 他のアプリケーションで開くplToolStripMenuItem
            // 
            this.他のアプリケーションで開くplToolStripMenuItem.Name = "他のアプリケーションで開くplToolStripMenuItem";
            this.他のアプリケーションで開くplToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.他のアプリケーションで開くplToolStripMenuItem.Text = "他のアプリケーションで開く";
            // 
            // エクスプローラーで開くplToolStripMenuItem
            // 
            this.エクスプローラーで開くplToolStripMenuItem.Name = "エクスプローラーで開くplToolStripMenuItem";
            this.エクスプローラーで開くplToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.エクスプローラーで開くplToolStripMenuItem.Text = "エクスプローラーで開く";
            // 
            // 通常サイズに戻すplToolStripMenuItem
            // 
            this.通常サイズに戻すplToolStripMenuItem.Name = "通常サイズに戻すplToolStripMenuItem";
            this.通常サイズに戻すplToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.通常サイズに戻すplToolStripMenuItem.Text = "通常サイズに戻す";
            // 
            // ListContextMenuStrip
            // 
            this.ListContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.プレイリスト表示LCToolStripMenuItem,
            this.上の階層をリストアップLCToolStripMenuItem,
            this.読めないファイルを削除LCToolStripMenuItem,
            this.他のリストに結合LCToolStripMenuItem,
            this.リストファイル選択LCToolStripMenuItem});
            this.ListContextMenuStrip.Name = "ListContextMenuStrip";
            this.ListContextMenuStrip.Size = new System.Drawing.Size(184, 114);
            this.ListContextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.PlaylistAddMenuStrip_Opening);
            this.ListContextMenuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ListContextMenuStrip_ItemClicked);
            // 
            // プレイリスト表示LCToolStripMenuItem
            // 
            this.プレイリスト表示LCToolStripMenuItem.Name = "プレイリスト表示LCToolStripMenuItem";
            this.プレイリスト表示LCToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.プレイリスト表示LCToolStripMenuItem.Text = "プレイリスト表示";
            // 
            // 上の階層をリストアップLCToolStripMenuItem
            // 
            this.上の階層をリストアップLCToolStripMenuItem.Name = "上の階層をリストアップLCToolStripMenuItem";
            this.上の階層をリストアップLCToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.上の階層をリストアップLCToolStripMenuItem.Text = "上の階層をリストアップ";
            // 
            // 読めないファイルを削除LCToolStripMenuItem
            // 
            this.読めないファイルを削除LCToolStripMenuItem.Name = "読めないファイルを削除LCToolStripMenuItem";
            this.読めないファイルを削除LCToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.読めないファイルを削除LCToolStripMenuItem.Text = "読めないファイルを削除";
            // 
            // 他のリストに結合LCToolStripMenuItem
            // 
            this.他のリストに結合LCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.先頭に挿入LCToolStripMenuItem,
            this.末尾に追加LCToolStripMenuItem});
            this.他のリストに結合LCToolStripMenuItem.Name = "他のリストに結合LCToolStripMenuItem";
            this.他のリストに結合LCToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.他のリストに結合LCToolStripMenuItem.Text = "他のリストに結合";
            // 
            // 先頭に挿入LCToolStripMenuItem
            // 
            this.先頭に挿入LCToolStripMenuItem.Name = "先頭に挿入LCToolStripMenuItem";
            this.先頭に挿入LCToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.先頭に挿入LCToolStripMenuItem.Text = "先頭";
            // 
            // 末尾に追加LCToolStripMenuItem
            // 
            this.末尾に追加LCToolStripMenuItem.Name = "末尾に追加LCToolStripMenuItem";
            this.末尾に追加LCToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.末尾に追加LCToolStripMenuItem.Text = "末尾";
            // 
            // リストファイル選択LCToolStripMenuItem
            // 
            this.リストファイル選択LCToolStripMenuItem.Name = "リストファイル選択LCToolStripMenuItem";
            this.リストファイル選択LCToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.リストファイル選択LCToolStripMenuItem.Text = "リストファイル選択";
            // 
            // CurrentPositionTimer
            // 
            this.CurrentPositionTimer.Tick += new System.EventHandler(this.CurrentPositionTimer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1544, 712);
            this.Controls.Add(this.baseSplitContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1055, 39);
            this.Name = "Form1";
            this.Text = "After watching the contents(中身を見てから消すか残すか決められる)File browser";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.fileTreeContextMenuStrip.ResumeLayout(false);
            this.baseSplitContainer.Panel1.ResumeLayout(false);
            this.baseSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.baseSplitContainer)).EndInit();
            this.baseSplitContainer.ResumeLayout(false);
            this.FileBrowserSplitContainer.Panel1.ResumeLayout(false);
            this.FileBrowserSplitContainer.Panel1.PerformLayout();
            this.FileBrowserSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FileBrowserSplitContainer)).EndInit();
            this.FileBrowserSplitContainer.ResumeLayout(false);
            this.FileBrowserCenterSplitContainer.Panel1.ResumeLayout(false);
            this.FileBrowserCenterSplitContainer.Panel2.ResumeLayout(false);
            this.FileBrowserCenterSplitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FileBrowserCenterSplitContainer)).EndInit();
            this.FileBrowserCenterSplitContainer.ResumeLayout(false);
            this.FileViewBodySplitContainer.Panel1.ResumeLayout(false);
            this.FileViewBodySplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FileViewBodySplitContainer)).EndInit();
            this.FileViewBodySplitContainer.ResumeLayout(false);
            this.viewSplitContainer.Panel1.ResumeLayout(false);
            this.viewSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.viewSplitContainer)).EndInit();
            this.viewSplitContainer.ResumeLayout(false);
            this.PlayListsplitContainer.Panel1.ResumeLayout(false);
            this.PlayListsplitContainer.Panel2.ResumeLayout(false);
            this.PlayListsplitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayListsplitContainer)).EndInit();
            this.PlayListsplitContainer.ResumeLayout(false);
            this.PlayListTopSplitContainer.Panel1.ResumeLayout(false);
            this.PlayListTopSplitContainer.Panel1.PerformLayout();
            this.PlayListTopSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PlayListTopSplitContainer)).EndInit();
            this.PlayListTopSplitContainer.ResumeLayout(false);
            this.MediaPlayerSplitContainer.Panel1.ResumeLayout(false);
            this.MediaPlayerSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MediaPlayerSplitContainer)).EndInit();
            this.MediaPlayerSplitContainer.ResumeLayout(false);
            this.MediaPlayerPanel.ResumeLayout(false);
            this.progresPanel.ResumeLayout(false);
            this.progresPanel.PerformLayout();
            this.MediaControlPanel.ResumeLayout(false);
            this.MediaControlPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VolBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MediaPositionTrackBar)).EndInit();
            this.PlayListContextMenuStrip.ResumeLayout(false);
            this.ListContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.TreeView fileTree;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lastWriteTime;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label fileLength;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label creationTime;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lastAccessTime;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label rExtension;
		private System.Windows.Forms.ImageList imageList1;
		private System.Windows.Forms.Label passNameLabel;
		private System.Windows.Forms.Label fileNameLabel;
		private System.Windows.Forms.SplitContainer baseSplitContainer;
		private System.Windows.Forms.SplitContainer FileBrowserSplitContainer;
		private System.Windows.Forms.SplitContainer FileBrowserCenterSplitContainer;
		private System.Windows.Forms.Label mineType;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label typeName;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ContextMenuStrip fileTreeContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem 削除ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem フォルダ作成ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 他のアプリケーションで開くToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 元に戻す;
		private System.Windows.Forms.ToolStripMenuItem コピーToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem ペーストToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem カットToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 名称変更ToolStripMenuItem;
		private System.Windows.Forms.CheckBox continuousPlayCheckBox;
		private System.Windows.Forms.SplitContainer viewSplitContainer;
		private System.Windows.Forms.ListBox playListBox;
//		public System.Windows.Forms.WebBrowser playerWebBrowser;
		private System.Windows.Forms.SplitContainer PlayListsplitContainer;
		private System.Windows.Forms.ToolStripMenuItem 再生ToolStripMenuItem;
		private System.Windows.Forms.Panel progresPanel;
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.Label ProgressTitolLabel;
		private System.Windows.Forms.Label targetCountLabel;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label progCountLabel;
		private System.Windows.Forms.Label ProgressMaxLabel;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label prgMessageLabel;
		private System.Windows.Forms.Label plTotalLabel;
		private System.Windows.Forms.Label plPosisionLabel;
		private System.Windows.Forms.ContextMenuStrip PlayListContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem ファイルブラウザで選択plToolStripMenuItem;
		private System.Windows.Forms.TextBox parentPathLabel;
		private System.Windows.Forms.TextBox grarnPathLabel;
		private System.Windows.Forms.ToolStripMenuItem プレイリストに追加ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem プレイリストを作成ToolStripMenuItem;
		private System.Windows.Forms.SplitContainer PlayListTopSplitContainer;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.ComboBox PlaylistComboBox;
		private System.Windows.Forms.ToolStripMenuItem 削除plToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 他のアプリケーションで開くplToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem videoFT2PLToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem audioFT2PLToolStripMenuItem;
		private System.Windows.Forms.ContextMenuStrip ListContextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem 上の階層をリストアップLCToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 読めないファイルを削除LCToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 他のリストに結合LCToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 先頭に挿入LCToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 末尾に追加LCToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem リストファイル選択LCToolStripMenuItem;
		private System.Windows.Forms.SplitContainer FileViewBodySplitContainer;
		private System.Windows.Forms.ListView FilelistView;
		private System.Windows.Forms.ColumnHeader SizeColumnHeader;
		private System.Windows.Forms.ColumnHeader UpDateColumnHeader;
		private System.Windows.Forms.ToolStripMenuItem エクスプローラーで開くplToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem titolToolStripMenuItem;
		private System.Windows.Forms.ColumnHeader NameColumnHeader;
		private System.Windows.Forms.ToolStripMenuItem 通常サイズに戻すToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 通常サイズに戻すplToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem プレイリスト表示LCToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem このファイルを再生ToolStripMenuItem;
		private System.Windows.Forms.SplitContainer MediaPlayerSplitContainer;
		private System.Windows.Forms.Panel MediaControlPanel;
		private System.Windows.Forms.Panel MediaPlayerPanel;
		private System.Windows.Forms.TrackBar MediaPositionTrackBar;
		private System.Windows.Forms.TrackBar VolBar;
		private System.Windows.Forms.Label CarentTime;
		private System.Windows.Forms.Label PlayTitolLabel;
		private System.Windows.Forms.Label EndTime;
		private System.Windows.Forms.Label VolLabel;
		private System.Windows.Forms.Button PlayPouseButton;
		private System.Windows.Forms.Button plRewButton;
		private System.Windows.Forms.Button plNextBbutton;
        private System.Windows.Forms.Timer CurrentPositionTimer;
        //		private System.Windows.Forms.PictureBox PlayerPictureBox;
    }
}

